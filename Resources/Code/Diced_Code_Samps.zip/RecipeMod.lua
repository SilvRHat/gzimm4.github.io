--[[ Tropical Recipe Mod ]] local recipe={}

-- Gavin Zimmerman | Written for Diced by Plated Studios
-- 07/28/2020

--[[Structure
		Variables
		Client Functions
		Server Functions
		Module build and interaction handler table
]]


-- API Services
local runService=game:GetService('RunService')
local players=game:GetService('Players')
local httpService=game:GetService('HttpService')
local repStorage= game:GetService('ReplicatedStorage')
local tweenService=game:GetService('TweenService')

-- Script dependencies / connections
local connections=repStorage:FindFirstChild('Connections')
local RECIPE_CONTROL=connections:FindFirstChild('RECIPE_CONTROL')
local RECIPE_SIG=connections:FindFirstChild('RECIPE_SIG')

local SKILL_SERVER_HANDLER=connections:FindFirstChild("SKILL_SERVER_HANDLER")

local SKILL_CLIENT_HANDLER=connections:FindFirstChild("SKILL_CLIENT_HANDLER")
local BONUS_SIGNAL=connections:FindFirstChild('BONUS_SIGNAL')
local UI_FOCUS_SIG=connections:FindFirstChild('UI_FOCUS_SIGNAL')

local device=require(repStorage:FindFirstChild('DeviceCheck'))
local EUI = require(repStorage:FindFirstChild("UI_Universals"))



-- Configurations
local playerStore={}

local ps_Def={
	actions={
		coroutine=nil,
		callback=nil,
		connection=nil,
		status='ready'
	},
	pizza_oven = {
		coroutine=nil,
		callback=nil,
		connection=nil
	},
	score={
		submitted=false,
		dough={},
		finish={},
		
		order={},
		toppings={},
		
		time={
			begin=0,
			fin=0,
		},
		
		bonuses={
			
		}
	}
}

local gameState

-- For recipe
local ingredient_list={
	Yeast= {amt=1, extra="[Dough]"},
	Flour= {amt=2, extra="[Dough]"},
	Coconut= {amt=1, extra="[Has Water]"},
	Sauce= {amt=1, extra="[Topping]"},
	Cheese= {amt=1, extra="[Topping]"},
	Pineapple= {amt=1, extra="[Topping]"},
	Sashimi= {amt=1, extra="[Topping]"},
	Flowers= {amt=1, extra="[Garnish]"}
}

local cuts={
	Cheese = {msg='Shred', base=6, frames=4, tool = 'Knife'},
	Pineapple = {msg='Rough chop', base=5, frames=5, tool = 'Knife'},
	Ham = {msg='Cube', base=7, frames=4, tool = 'Knife'},
	Fish = {msg='Break Down', base=12, frames=7, tool = 'Knife'}, 
	Coconut = {msg='Crack', base=6, frames=5, tool = 'Machete'}
}
local cut_arr = {'Cheese','Pineapple','Ham','Fish'}

local score_conf= {
	dough ={
		dry_ratio=2,	-- FLOUR / YEAST
		wet_ratio=3,		-- FLOUR + YEAST / WATER
		amt={
			Yeast = {quantity=1, value = .4},
			Flour = {quantity=2, value = .3},
			Water = {quantity=1, value = .5},
		}
	},
	toppings = {
		order = {'Sauce','Cheese','Pineapple','Fish','Flowers'},
		order_mult = .75,
		amt={
			Sauce = {quantity =1, value = .5},
			Cheese = {quantity=1, value = 1},
			Pineapple = {quantity=1, value = 1.25},
			Fish = {quantity=1, value = 2},
			Flowers = {quantity=1, value = .75}
		}
	},
	cook = {
		info = {
			Pizza = {
				goal = .6,
				base = 15,
				total = 4
			}
		},
		amt = {
			Dough = {quantity =1, percent=4/8},
			Sauce = {quantity =1, percent=1/16},
			Cheese = {quantity =1, percent=1/8},
			Pineapple = {quantity =1, percent=1/8},
			Fish = {quantity =1, percent=3/16},
		},
		mult = {
			Flowers = 2.2
		},
		
	}
}
local pizza_oven_lookup={}
local stove_actions = {}


-- Handle current recipe only
local id=httpService:GenerateGUID(false)
local current

RECIPE_CONTROL.Event:Connect(function (runningId)
	current=runningId
end)
local function isRunning()
	return current==id
end





local function getSkill(x, player)
	if runService:IsClient() then
		return SKILL_CLIENT_HANDLER:InvokeServer()[x]
	else
		return SKILL_SERVER_HANDLER:Invoke(player)[x]
	end
end


local function getFinalScore(id, considerTime)
	local score_data = playerStore[id].score
	
	local sum=0
	for _, points in pairs(score_data.dough) do
		sum=sum+points
	end
	for _, points in pairs(score_data.toppings) do
		sum=sum+points
	end
	for x, points in pairs(score_data.finish) do
		sum=sum+points
	end
	
	if considerTime then
		local time = score_data.time.begin - score_data.time.fin
		return sum / ( math.max(time, 75) * .014 )
	end
	return sum
end


local function loadIngredients(map)
	for _, obj in pairs(script.Parent.IngredientStorage:GetChildren()) do
		if map:FindFirstChild(obj.Name, true) then
			
			obj = obj:Clone()
			obj:SetPrimaryPartCFrame(map:FindFirstChild(obj.Name).Value)
			map:FindFirstChild(obj.Name):Destroy()
			obj.Parent=map
		end
	end
end


local function sendScores(duration)
	-- Create score UI
	local scores=Instance.new('Frame')
	scores.Size=UDim2.new(1,0,1,0)
	scores.Transparency=1
	
	for userId, data in pairs(playerStore) do
		if not players:GetPlayerByUserId(userId) then
			continue
		end
		local scoreBox=script.Parent.ScoreTemp:Clone()
		scoreBox.Parent=scores
		
		local dough, toppings, finish = 0,0,0
		for _, points in pairs(data.score.dough) do
			dough=dough+points
		end
		for _, points in pairs(data.score.toppings) do
			toppings=toppings+points
		end
		for _, points in pairs(data.score.finish) do
			finish= finish+points
		end
		local time = data.score.time.begin - data.score.time.fin
		
		scoreBox.PlayerName.Text=players:GetPlayerByUserId(userId).Name
		scoreBox.Dough.Text= string.format('%.2f',dough)
		scoreBox.Toppings.Text = string.format('%.2f',toppings)
		scoreBox.Finish.Text = string.format('%.2f',finish)
		scoreBox.Time.Text = math.floor(time/60)..':'..string.sub('0'..tostring(time%60),-2)
		scoreBox.Final.Text = string.format('%.3f', getFinalScore(userId, true))
	end
	scores.Parent=repStorage

	RECIPE_SIG:FireAllClients('SCORES',{scores=scores, time=(duration or 8)})
	scores:Destroy()
end


-- displayRecipe() REMOVED FROM CODE SAMPLE


local function displayScores(state,args)
	if not (isRunning() and state=='SCORES') then
		return
	end
	
	local scores = args.scores:Clone()
	
	scores.Parent=players.LocalPlayer.PlayerGui.Main.Score
	local boxes=scores:GetChildren()
	local x=#boxes
	local freeSpace = 1-(.22*x)
	local p=freeSpace/(x+1)
	
	for i,box in pairs(boxes) do
		local xPosSc=(i*(p+.11))+((i-1)*.11)
		box.Position=UDim2.new(-.5,0,box.Position.Y.Scale,0)
		box:TweenPosition(UDim2.new(xPosSc,0,box.Position.Y.Scale,0), Enum.EasingDirection.Out, Enum.EasingStyle.Quad, 1, true)
		wait(1/4)
	end

	
	wait(args.time)
	for i,box in pairs(boxes) do
		box:TweenPosition(UDim2.new(1.5,0,box.Position.Y.Scale,0), Enum.EasingDirection.In, Enum.EasingStyle.Quad, 1, true)
		wait(1/4)
	end
end





-- Returns if action is interactable given arguments, returns message to display user and time action will take
local function checkContext(player, modeObj, lvl)
	-- Manipulate lvl
	local getSkill = getSkill
	if lvl then
		getSkill = (function () return lvl end)
	end
	
	local char= player.Character
	if not (char and modeObj and modeObj:FindFirstChild('Type')) then
		return
	end
	
	local mode = modeObj:FindFirstChild('Type')['Value']
	local tool = char:FindFirstChildOfClass('Tool')
	-- Add, Sub, Mixer, Cut, POven, Oven, Open, Plate, Serve
	
	if mode == 'Add' and not tool then	-- Universal recipe
		-- Check that player isn't carrying anything
		return true, modeObj:FindFirstChild('Message')['Value'] or 'Take ingedient', 0
		
	elseif mode=='Sub' and tool then
		-- Check that player is carrying something
		return true, 'Trash', 0
		
	elseif mode=='Mixer' then

		if tool and tool:FindFirstChild('Ingredient') then
			return true, 'Add to mixer', 0
		elseif not tool then
			local ingredients=0
			
			for _,obj in pairs(modeObj:GetChildren()) do
				ingredients = ingredients + (obj.Name=='Ingredient' and 1 or 0)
			end

			local process_time = (2 - (getSkill('MixerLvl',player)*.25))*ingredients
			return (process_time>1), 'Mix', process_time
		end	
		
	elseif mode=='Cut' then
		local pizza=modeObj:FindFirstChild('Pizza')
		local topping
		
		for _,cut in pairs(cut_arr) do
			topping = topping or modeObj:FindFirstChild(cut)
		end
		
		if not tool then
			if modeObj:FindFirstChild('Coconut') then
				return true, 'Take Coconut', 0
			end
			if pizza then
				if topping then
					return true, 'Place topping ('..topping.Name..')', 0
				else
					return true, 'Take pizza', 0
				end
			end
		else
			if modeObj:FindFirstChild('Coconut') then
				return false
				
			elseif tool.Name=='Pizza' and not pizza then
				return true, 'Set on pizza plate', 0
			elseif tool.Name=='Dough' and not pizza then
				return true, 'Roll dough', 9 - ( (2*getSkill('CutLvl',player) + 3*getSkill('MixerLvl',player) )/4 )
			elseif tool.Name=='TomatoSauce' and pizza then
				return true, 'Sauce pizza', 0
			elseif tool.Name=='Flowers' and pizza then
				return true, 'Top with flowers', 0
			elseif cuts[tool.Name] then
				local process_time = cuts[tool.Name].base - (cuts[tool.Name].base*(3/25)*getSkill('CutLvl',player))
				return true, cuts[tool.Name].msg, process_time 
			end
		end
		
	elseif mode=='PizzaOven' then
		if modeObj:FindFirstChild('Pizza'..player.UserId) and not tool then
			return true, 'Take pizza', 0
		elseif tool and not modeObj:FindFirstChild('Pizza'..player.UserId) then
			if tool.Name=='Pizza' then
				return true, 'Cook pizza', 0
			end
		end
		
	elseif mode=='Plate' and tool and tool.Name=="Pizza" then
		return true, 'Plate up pizza', 0
		
	elseif mode=='Serve' and tool and tool.Name=="Pizza" then
		return true, 'Serve it up!', 0
	end
	
	return false
end










--========================================================================================
-- BEGIN  Interaction handler functions
--========================================================================================


local function pickUp(plr, modeObj, process_time)
	local ing = script.Parent.Ingredients:FindFirstChild(modeObj.IngredientId.Value)
	if not ing then
		return
	end
	
	local char = plr.Character
	
	ing = ing:Clone()
	ing.Parent=plr.Backpack
	char:FindFirstChild('Humanoid'):EquipTool(ing)
end


local function trashTool(plr, modeObj, process_time)
	local char = plr.Character
	
	local tool=char:FindFirstChildOfClass('Tool')
	if tool and tool.Name=='Pizza' then
		playerStore[plr.UserId].score.toppings={}
		playerStore[plr.UserId].score.order={}
	end
	
	char:FindFirstChild('Humanoid'):UnequipTools()
	plr.Backpack:ClearAllChildren()
end


local function useMixer(plr, modeObj, process_time)
	local char=plr.Character
	local tool=char:FindFirstChildOfClass('Tool')
	
	if tool then
		local ingredients=0
		for _,obj in pairs(modeObj:GetChildren()) do
			ingredients = ingredients + (obj.Name=='Ingredient' and 1 or 0)
		end
		
		local ing=Instance.new('Part')
		ing.BrickColor=tool.Ingredient.BrickColor
		ing.Material=tool.Ingredient.Material
		
		local calc_xz = math.max( .4, .86 - (ingredients*.1) / ( 1 + (ingredients*.1) ) )
		local calc_y = math.min(.8 , .2 + (ingredients*.05) / ( 1 + (ingredients*.05) ) )
		local sub_y = .64 - (calc_y/2.5)
		
		if tool.Ingredient:FindFirstChild('Liquid') then
			ing.Transparency=.6
			calc_y = calc_y - (.86 - calc_xz)
			calc_xz = .8
			tool.Ingredient.Liquid.Parent=ing
		end
		
		ing.Size = Vector3.new(calc_xz, calc_y, calc_xz)
		ing.Position = modeObj.Parent.MixHandle.Position - Vector3.new(0,sub_y,0)
		ing.Anchored=true
		ing.CanCollide=false
		ing.Name='Ingredient'
		ing.Parent = modeObj
		
		local mesh=Instance.new('SpecialMesh')
		mesh.MeshType=Enum.MeshType.Sphere
		mesh.Parent = ing
		
		local id=Instance.new('StringValue')
		id.Name='IngredientId'
		id.Value=tool.Name
		id.Parent = ing
		
		char:FindFirstChild('Humanoid'):UnequipTools()
		plr.Backpack:ClearAllChildren()
		
	else
		local speed = math.rad(1) * 4 * ( math.pow(1.8, getSkill('MixerLvl',plr) -1 ) )
		
		local actions=playerStore[plr.UserId].actions
		actions.coroutine=coroutine.running()
		actions.connection= runService.Heartbeat:Connect(function (s)
			modeObj.Parent.MixHandle.CFrame=modeObj.Parent.MixHandle.CFrame* CFrame.Angles(0, speed, 0)
		end)
		
		wait(process_time)
		
		if not (actions.coroutine==coroutine.running()) then
			return
		end
		actions.connection:Disconnect()
		actions.connection = nil
		
		local doughBall = Instance.new('Part')
		local mix_list = {}
		local destroy_list={}
		local color={
			r=0,
			b=0,
			g=0,
		}
		local total_ingredients, liquids, color_div = 0,0,0
		
		for _, item in pairs(modeObj:GetDescendants()) do
			if item.Name=='IngredientId' then
				mix_list[item.Value] = 1 + (mix_list[item.Value] or 0)
				item.Parent=doughBall
				total_ingredients=total_ingredients+1
				
				if item.Value=='Tomatos' then
					item:destroy()
				end
				
			elseif item.Name=='Liquid' then
				liquids=liquids+1
				
			elseif item.Name=='Ingredient' then
				
				local influence = item:FindFirstChild('Liquid') and 0.05 or 1
				
				color.r= color.r + (item.Color.R * influence)
				color.b= color.b + (item.Color.B * influence)
				color.g= color.g + (item.Color.G * influence)
				color_div= (color_div + influence)
				
				table.insert(destroy_list, item)
			end
		end
		
		for _,obj in pairs(destroy_list) do
			obj:Destroy()
		end
		
		doughBall.Color = Color3.new(color.r / color_div, color.g / color_div, color.b / color_div)
		doughBall.Material = Enum.Material.Sand
		if liquids==total_ingredients then
			doughBall.Material = destroy_list[1].Material
			doughBall.Transparency = .6
		end
		
		local calc_y = math.min(.8 , .2 + (total_ingredients*.08) / (1 + (total_ingredients*.08) ) )
		local sub_y = .64 - (calc_y/2)
		
		doughBall.Size = Vector3.new(.86, calc_y, .86)
		doughBall.Position = modeObj.Parent.MixHandle.Position - Vector3.new(0,sub_y,0)
		doughBall.Anchored=true
		doughBall.CanCollide=false
		doughBall.Name='Ingredient'
		doughBall.Parent = modeObj
		
		local mesh=Instance.new('SpecialMesh')
		mesh.MeshType=Enum.MeshType.Sphere
		mesh.Parent=doughBall
		
		
		if mix_list['Flour'] and mix_list['Yeast'] then
			local dry_ratio = mix_list['Flour'] / mix_list['Yeast']
			local score_data = playerStore[plr.UserId].score
			
			if mix_list['Water'] then
				local wet_ratio = (mix_list['Flour'] + mix_list['Yeast']) / (mix_list['Water'] + (mix_list['Pineapple'] or 0) )
				
				-- Score
				local score = getFinalScore(plr.UserId)
				score_data.dough.dry_ratio = 1.5 - math.abs(dry_ratio - score_conf.dough.dry_ratio)
				score_data.dough.wet_ratio = 1.5 - math.abs(wet_ratio - score_conf.dough.wet_ratio)
				
				local amt=0
				for ing, quantity in pairs(mix_list) do
					if not score_conf.dough.amt[ing] then
						continue
					end
					quantity = math.min(quantity, score_conf.dough.amt[ing].quantity)
					amt = amt + quantity * score_conf.dough.amt[ing].value
				end
				score_data.dough.amt = amt
				
				local score = amt + score_data.dough.wet_ratio + score_data.dough.dry_ratio
				
				if score>0 then
					BONUS_SIGNAL:FireClient(plr, '+'..string.format('%.2f',score)..' Dough composition')
				end
				
				local size= math.min(mix_list['Yeast'], mix_list['Flour']/2, mix_list['Water'])
				local x = .4 + math.pow(1.2, size)
				
				local tool = Instance.new('Tool')
				tool.CanBeDropped=false
				tool.Name='Dough'
				tool.GripPos = Vector3.new(.2,-.2,(doughBall.Size.X/2)-.4)
				
				doughBall.Parent= tool
				doughBall.Name='Handle'
				doughBall.Anchored=false
				doughBall.Size=doughBall.Size*x
				
				local sizeTag=Instance.new('NumberValue')
				sizeTag.Value=size
				sizeTag.Name='Size'
				sizeTag.Parent=tool
				
				tool.Parent=plr.Backpack
				char:FindFirstChild('Humanoid'):EquipTool(tool)
				
				if mix_list['Flowers'] then
					local score= getFinalScore(plr.UserId)
					score_data.dough.coloredDoughBonus = 1.5
				
					score=getFinalScore(plr.UserId) - score
					if score>0 then
						BONUS_SIGNAL:FireClient(plr, '+1.5 Colorful Dough')
					end
				end
			else
				local score= getFinalScore(plr.UserId)
				score_data.dough['Mixed Well']=1.5
				
				score=getFinalScore(plr.UserId) - score
				if score>0 then
					BONUS_SIGNAL:FireClient(plr, '+1.5 Mixed Well')
				end
			end
		end
	end
end





local function scoreToppings(plr)
	local score_data = playerStore[plr.UserId].score
	local order_data = score_data.order
	
	local order_inverse_lookup = {}
	for i,v in pairs(score_conf.toppings.order) do
		order_inverse_lookup[v]=i
	end
	
	local max, current = 0,0
	local last=0
	
	-- Get order score
	local ing_list = {}
	for i=1, #order_data do
		ing_list[order_data[i]] = (ing_list[order_data[i]] or 0) +1
		
		local match=false
		for j=last+1, #score_conf.toppings.order do
			if order_data[i]==score_conf.toppings.order[j] then
				last=j
				current=current+1
				match=true
			end
		end
		
		if not match then
			current = 0			
		elseif current>max then
			max=current
		end
	end
	
	local amt,penalty=0,0
	for ing, quantity in pairs(ing_list) do
		if not score_conf.toppings.amt[ing] then
			continue
		end
		penalty = penalty + (math.max(0, quantity - score_conf.toppings.amt[ing].quantity) * (score_conf.toppings.amt[ing].value/2))
		quantity = math.min(quantity, score_conf.toppings.amt[ing].quantity)
		amt = amt + quantity * score_conf.toppings.amt[ing].value
	end
	
	local score = getFinalScore(plr.UserId)
	score_data.toppings.order = max * score_conf.toppings.order_mult
	score_data.toppings.amt = amt - penalty 
	
	score = getFinalScore(plr.UserId) - score
	if score>0 then
		BONUS_SIGNAL:FireClient(plr, '+'..string.format('%.2f',score)..' Topping')
	elseif score<0 then
		BONUS_SIGNAL:FireClient(plr, string.format('%.2f',score)..' Extra Topping')
	end
	
end

local function zeBoard(plr, modeObj, process_time)
	local char, body = plr.Character, plr.Character.HumanoidRootPart
	local tool=char:FindFirstChildOfClass('Tool')
	local actions=playerStore[plr.UserId].actions
	actions.coroutine=coroutine.running()
	
	local pizza=modeObj:FindFirstChild('Pizza')
	
	local adjust_info = TweenInfo.new(
		1,
		Enum.EasingStyle.Quart,
		Enum.EasingDirection.InOut
	)
	local adjust_frame = modeObj.Parent.Board.CFrame:ToWorldSpace(modeObj.Parent.Board.charRelOffset.Value)
	local adjust=tweenService:Create(body, adjust_info, {CFrame=adjust_frame, Velocity=Vector3.new(0,0,0) })
	
	local topping
	
	-- Regular cut
	if tool and cuts[tool.Name] then
		local frame
		
		-- Knife
		local _,_,speed_time = checkContext(plr, modeObj, 1)
		local knife = script.Parent.Tools:FindFirstChild(cuts[tool.Name].tool):Clone()
		knife.Speed.Value = speed_time / process_time
		knife.Parent=plr.Backpack
		
		local motor = Instance.new('Motor6D')
		motor.Part0 = char:FindFirstChild('LeftHand')
		motor.Part1 = knife.Handlething
		motor.Name='Knife'
		motor.Parent = char:FindFirstChild('LeftHand')
		
		-- Cancel
		actions.callback=function ()
			if adjust.PlaybackState==Enum.PlaybackState.Playing then
				adjust:Pause()
			end
			
			if frame then
				frame:Destroy()
			end
			
			motor:Destroy()
			char.Humanoid:UnequipTools()
			char.Humanoid:EquipTool(tool)
		end
		
		-- Action
		adjust:Play()
		char.Humanoid:EquipTool(knife)
		
		for i=1, cuts[tool.Name].frames do
			if actions.coroutine~=coroutine.running() then
				return
			end
			-- Display
			if frame then
				frame:Destroy()
			end
			
			frame = script.Parent.ToppingFrames:FindFirstChild(tool.Name..'Anim'..i):Clone()
			frame:SetPrimaryPartCFrame(modeObj.Parent.Board.CFrame)
			frame.PrimaryPart:Destroy()
			frame.Parent=modeObj
			
			wait(process_time/cuts[tool.Name].frames)
		end
		
		-- Complete
		if actions.coroutine~=coroutine.running() then
			return
		end
		
		if script.Parent.ToppingFrames.MiseEnPlace:FindFirstChild(tool.Name) then
			local miseEnPlace = script.Parent.ToppingFrames.MiseEnPlace:Clone()
			topping = miseEnPlace:FindFirstChild(tool.Name)
			
			miseEnPlace:SetPrimaryPartCFrame(modeObj.Parent.Board.CFrame)
			topping.Parent=modeObj
			miseEnPlace:Destroy()
		end
		actions.callback=nil
		
		if tool.Name~='Coconut' then
			tool = nil
		end
		
		motor:Destroy()
		char.Humanoid:UnequipTools()
		frame:Destroy()
		plr.Backpack:ClearAllChildren()
	end
	
	-- Place topping
	for _,cut in pairs(cut_arr) do
		topping = topping or modeObj:FindFirstChild(cut)
	end
	
	if not tool then
		if modeObj:FindFirstChild('Coconut') then
			modeObj:FindFirstChild('Coconut'):Destroy()
			local water=script.Parent.Ingredients.Water:Clone()
			water.Parent=plr.Backpack
			char.Humanoid:EquipTool(water)
		
		elseif pizza and topping then
			local selection=script.Parent.Ingredients.Toppings:FindFirstChild(topping.Name)
			if not selection then
				return
			end
			
			local selection = selection:Clone()
			
			local r=pizza.PrimaryPart.Size.X/2
			for _, obj in pairs(selection:GetChildren()) do
				-- Calculate topping coordinates on pizza
				local rand_x, rand_z
				
				repeat
					rand_x = math.random(-r*100,r*100)/100
					rand_z = math.random(-r*100,r*100)/100
				until (.8 * r > math.sqrt(math.pow(rand_x,2)+math.pow(rand_z,2))  )
				
				local layers=0
				for _, pizzaObj in pairs(pizza:GetChildren()) do
					layers = layers + (cuts[pizzaObj.Name] and 1 or 0)
				end
				
				local y=(layers*.0125)+.05
				obj.Position=pizza.PrimaryPart.Position+Vector3.new(rand_x,y,rand_z)
				
			end
			selection.Parent=pizza
			topping:Destroy()
			
			table.insert(playerStore[plr.UserId].score.order, topping.Name)
			scoreToppings(plr)
			
		elseif pizza then
			-- Take pizza
			for _,v in pairs(pizza:GetDescendants()) do
				if (v:IsA('BasePart')) then
					v.Anchored=false
					v.CanCollide=false
				elseif v:IsA('Weld') or v:IsA('CFrameValue') then
					v:Destroy()
				end
			end
			
			local peel=script.Parent.Tools.PizzaPeel:Clone()
			peel.Name='Pizza'
			peel.Parent=plr.Backpack
			
			pizza.Parent=peel
			pizza:SetPrimaryPartCFrame(peel.Plate.CFrame+Vector3.new(0,.1,0))
			
			char:FindFirstChild('Humanoid'):EquipTool(peel)
		end
		
	else
		if tool.Name=='Pizza' then
			for _,v in pairs(tool:GetDescendants()) do
				if (v:IsA('BasePart')) then
					v.Anchored=true
				elseif v:IsA('Weld') or v:IsA('CFrameValue') then
					v:Destroy()
				end
			end
			
			pizza=tool:FindFirstChild('Pizza')
			pizza.Parent=modeObj
			pizza:SetPrimaryPartCFrame((modeObj.Parent.PizzaPlate.CFrame*CFrame.Angles(0,0,math.rad(-90)))+Vector3.new(0,.1,0))
			
			char:FindFirstChild('Humanoid'):UnequipTools()
			plr.Backpack:ClearAllChildren()
			
			
		elseif tool.Name=='Dough' then
			local doughBall
			
			-- Rolling Pin
			local _,_,speed_time = checkContext(plr, modeObj, 1)
			local rollingPin = script.Parent.Tools.RollinPin:Clone()
			rollingPin.Speed.Value = speed_time / process_time
			rollingPin.Parent=plr.Backpack
			
			local motor = Instance.new('Motor6D')
			motor.Part0 = body
			motor.Part1 = rollingPin.BodyAttach
			motor.Name='RollingPin'
			motor.Parent = body
			
			-- Cancel
			actions.callback=function ()
				if adjust.PlaybackState==Enum.PlaybackState.Playing then
					adjust:Pause()
				end
				
				motor:Destroy()
				char.Humanoid:UnequipTools()
				
				char.Humanoid:EquipTool(tool)
				doughBall:Destroy()
			end
			
			
			-- Action
			adjust:Play()
			char.Humanoid:EquipTool(rollingPin)
			
			-- First Half
			doughBall = tool.Handle:Clone()
			doughBall.Name = 'Dough'
			doughBall.Anchored=true
			doughBall.CFrame=modeObj.Parent.Board.CFrame+Vector3.new(0,.2,0)
			doughBall.Parent=modeObj
			
			wait(process_time/2)
			
			if coroutine.running()~=actions.coroutine then -- Second half
				return
			end

			local xz = doughBall.Size.X*1.5
			doughBall.Size=Vector3.new(xz,.4,xz)
			doughBall.Position=doughBall.Position-Vector3.new(0,0.1,0)
			
			wait(process_time/2)
			if coroutine.running()~=actions.coroutine then	-- Complete
				return
			end
			
			actions.callback=nil
			tool = nil
			doughBall:Destroy()
			motor:Destroy()
			char.Humanoid:UnequipTools()
			plr.Backpack:ClearAllChildren()
			
			xz=xz*1.25
			
			local pizzaObj = Instance.new('Model')
			pizzaObj.Name = 'Pizza'
			pizzaObj.Parent = modeObj

			local rolledDough=script.Parent.Ingredients.flatDough:Clone()
			rolledDough.BrickColor=doughBall.BrickColor
			rolledDough.Size=Vector3.new(xz,.16,xz)
			rolledDough.Position=modeObj.Parent:FindFirstChild('PizzaPlate').Position+Vector3.new(0,.1,0)
			rolledDough.Name='Dough'
			rolledDough.Parent=pizzaObj
			
			pizzaObj.PrimaryPart=rolledDough
			
		elseif tool.Name=='TomatoSauce' and pizza then

			local sauce=Instance.new('Part')
			sauce.CanCollide=false
			sauce.Anchored=true
			sauce.Material=Enum.Material.Slate
			sauce.BrickColor=BrickColor.new('Persimmon')
			sauce.Parent=pizza
			sauce.Name='Sauce'
			
			local xz=pizza:FindFirstChild('Dough').Size.X*(.95)
			
			sauce.Size=Vector3.new(xz,.08,xz)
			sauce.Position=pizza:FindFirstChild('Dough').Position
			
			local mesh=Instance.new('SpecialMesh')
			mesh.MeshType=Enum.MeshType.Sphere
			mesh.Parent=sauce
			
			char:FindFirstChild('Humanoid'):UnequipTools()
			plr.Backpack:ClearAllChildren()
			
			table.insert(playerStore[plr.UserId].score.order, 'Sauce')
			scoreToppings(plr)
			
		elseif tool.Name=='Flowers' and pizza then
			local dough=pizza.PrimaryPart
			local r=dough.Size.X/2
			
			local flowers = script.Parent.Ingredients.Toppings.Flowers:Clone()
			flowers:SetPrimaryPartCFrame(dough.CFrame:ToWorldSpace(CFrame.new(r*.9,0.22,0)))
			flowers.Parent=pizza
			
			char:FindFirstChild('Humanoid'):UnequipTools()
			plr.Backpack:ClearAllChildren()
			
			table.insert(playerStore[plr.UserId].score.order, 'Flowers')
			scoreToppings(plr)
		end
	end
end





local function medRare(topping)
	local pizza=topping.Parent
	
	if topping.Name=='Cheese' then
		local t=topping:FindFirstChild('Tick') or {}
		t.Parent=nil
		topping:ClearAllChildren()
		t.Parent=topping
		
		local r=pizza.PrimaryPart.Size.X/2
		for i=1, 6 do
			local c =Instance.new('Part')
			c.BrickColor=BrickColor.new("Cool yellow")
			c.Material=Enum.Material.Foil
			
			local x1,z1,x2,z2
			repeat
				x1 = math.random(-r*100,r*100)/100
				z1 = math.random(-r*100,r*100)/100
			until (.9 * r > math.sqrt(math.pow(x1,2)+math.pow(z1,2))  )
			
			repeat
				x2 = math.random(-r*100,r*100)/100
				z2 = math.random(-r*100,r*100)/100
			until (.9 * r > math.sqrt(math.pow(x2,2)+math.pow(z2,2))  )
			
			c.Size=Vector3.new(math.abs(x1-x2), .12, math.abs(z1-z2))
			c.Position=pizza.PrimaryPart.Position+Vector3.new((x1+x2)/2,.016,(z1+z2)/2)
			c.Anchored=true
			c.CanCollide=false
			c.Parent=topping
			
			local mesh=Instance.new('SpecialMesh')
			mesh.MeshType=Enum.MeshType.Sphere
			mesh.Parent=c
		end
		
	elseif topping.Name=='Dough' then
		topping.Color=Color3.new(math.max(topping.Color.R - (20/255), 0), math.max(topping.Color.G - (29/255),0), math.max(topping.Color.B - (58/255),0))
	end
end

local function golden(topping)
	local pizza = topping.Parent
	
	if topping.Name=='Sauce' then
		topping.BrickColor=BrickColor.new("Terra Cotta")
		
	elseif topping.Name=='Cheese' then
		local t=topping:FindFirstChild('Tick') or {}
		t.Parent = nil
		topping:Destroy()
	
		topping=Instance.new('Part')
		topping.Name='Cheese'
		topping.Anchored=true
		topping.CanCollide=false
		topping.BrickColor=BrickColor.new('Cool yellow')
		topping.Material=Enum.Material.Sand
		topping.Size=Vector3.new(pizza.PrimaryPart.Size.X*.75, .12, pizza.PrimaryPart.Size.Z*.75)
		topping.Position=pizza.PrimaryPart.Position+Vector3.new(0,.016,0)
		topping.Parent=pizza
		
		t.Parent=topping
		
		
		local mesh=Instance.new('SpecialMesh')
		mesh.MeshType=Enum.MeshType.Sphere
		mesh.Parent=topping
		
	elseif topping.Name=='Fish' then
		for _,sashimi in pairs(topping:GetChildren()) do
			if not sashimi:IsA('BasePart') then
				continue
			end
			sashimi.BrickColor=BrickColor.new('Pastel orange')
			sashimi.UsePartColor=true
		end
		
	elseif topping.Name=='Dough' then
		topping.Color=Color3.new(math.max(topping.Color.R + (10/255), 0), math.max(topping.Color.G - (22/255),0), math.max(topping.Color.B - (20/255),0))
		
	end
	
end





local pizza_cook_table= {
	{percent=.15},	-- Raw-
	{percent=.25, handler = medRare},	-- Medium-rare
	{percent=.25, handler = golden},	-- Golden
	{percent=.2, handler = charr},	-- Charred crust [REMOVED FROM SAMPLE CODE]
	{percent=.25, handler = burnin},	-- Burning [REMOVED FROM SAMPLE CODE]
}

local percent_invariant=0
for _, cook_state in pairs(pizza_cook_table) do
	percent_invariant = percent_invariant + cook_state.percent
	cook_state.frameTime = percent_invariant * score_conf.cook.info.Pizza.base
end

local function pizzaz (plr, modeObj, process_time)
	local char = plr.Character
	local tool=char:FindFirstChildOfClass('Tool')
	local data = playerStore[plr.UserId].pizza_oven
		
	if pizza_oven_lookup[plr.UserId] then
		pizza_oven_lookup[plr.UserId]=nil
		
		local pizza=modeObj:FindFirstChild('Pizza'..plr.UserId)
		if not pizza then
			return
		end
		
		for _,v in pairs(pizza:GetDescendants()) do
			if (v:IsA('BasePart')) then
				v.Anchored=false
				v.CanCollide=false
			elseif v:IsA('Weld') or v:IsA('CFrameValue') then
				v:Destroy()
			end
		end
		
		local peel=script.Parent.Tools.PizzaPeel:Clone()
		peel.Name='Pizza'
		peel.Parent=plr.Backpack
		
		pizza.Name='Pizza'
		pizza.Parent=peel
		pizza:SetPrimaryPartCFrame(peel.Plate.CFrame+Vector3.new(0,0.1,0))
		
		char:FindFirstChild('Humanoid'):EquipTool(peel)
		
		data.connection:Disconnect()
		pizza_oven_lookup[plr.UserId] = nil
		
		--Score cook time
		local cook_points={}
		local sum=0
		for _, topping in pairs(pizza:GetChildren()) do
			if not score_conf.cook.amt[topping.Name] then
				continue
			end
			
			local time = (topping:FindFirstChild('Tick') and topping.Tick.Value) or 0

			local percent = score_conf.cook.amt[topping.Name].percent
			local points = percent * (-math.pow( (time - (score_conf.cook.info.Pizza.base * score_conf.cook.info.Pizza.goal ))/3 , 2) + score_conf.cook.info.Pizza.total)
			
			cook_points[topping.Name] = cook_points[topping.Name] or {}
			if score_conf.cook.amt[topping.Name].quantity-#cook_points[topping.Name]>0 then
				table.insert(cook_points[topping.Name], points)
				sum=sum+points
			end
		end
		
		
		local score = getFinalScore(plr.UserId)
		local score_data = playerStore[plr.UserId].score
		
		score_data.finish.cook = math.max(0, sum)
		
		score = getFinalScore(plr.UserId) - score
		
		if score>0.5 then
			BONUS_SIGNAL:FireClient(plr, '+'..string.format('%.2f',score)..' Cooking')
		end
		
	elseif tool and tool.Name == 'Pizza' then
		-- Get vacant spot
		local occupied={}
		for id, spot in pairs(pizza_oven_lookup) do
			occupied[spot]=true
		end
		local vacant=1
		for i,v in ipairs(occupied) do
			if v then
				vacant=vacant+1
			end
		end
		
		-- Place pizza in oven
		for _,v in pairs(tool:GetDescendants()) do
			if (v:IsA('BasePart')) then
				v.Anchored=true
			elseif v:IsA('Weld') or v:IsA('CFrameValue') then
				v:Destroy()
			end
		end
		
		local pizza=tool:FindFirstChild('Pizza')
		pizza.Name='Pizza'..plr.UserId
		pizza.Parent=modeObj
		pizza:SetPrimaryPartCFrame((modeObj.Parent:FindFirstChild('Spot'..vacant).CFrame*CFrame.Angles(0,0,0))+Vector3.new(0,.1,0))
		
		char:FindFirstChild('Humanoid'):UnequipTools()
		plr.Backpack:ClearAllChildren()
		
		pizza_oven_lookup[plr.UserId] = vacant
		
		
		
		local lvl = getSkill('CookLvl',plr)
		local ampl = 1
		local inc = .5 + (lvl*.15)
		local freq = 10
		
		local function killPizza()
			data.connection:Disconnect()
			pizza:Destroy()
			
			pizza_oven_lookup[plr.UserId] = nil
			
			playerStore[plr.UserId].score.finish.fire = (playerStore[plr.UserId].score.finish.fire or 0) - 2.5
			BONUS_SIGNAL:FireClient(plr, '-2.5 PIZZA BURNT!')
			
			playerStore[plr.UserId].score.toppings={}
			playerStore[plr.UserId].score.order={}
		end
		
		data.connection = runService.Heartbeat:Connect(function (step)
			local x = math.rad( ((tick()%freq)*(360/freq)) -180)
			local sine = (math.sin(x) * (ampl/2) ) + inc	
			
			for _, topping in pairs(pizza:GetChildren()) do
				local t = topping:FindFirstChild('Tick')
				if not t then
					t=Instance.new('NumberValue')
					t.Name='Tick'
					t.Parent=topping
				end
				
				local state=0
				for _, cook_state in ipairs(pizza_cook_table) do
					state=state+1
					if t.Value<cook_state.frameTime then
						break
					end
				end
				
				t.Value=t.Value + (sine * step * (score_conf.cook.mult[topping.Name] or 1))
				
				
				if t.Value>pizza_cook_table[state].frameTime then
					state=state+1
					if not pizza_cook_table[state] then
						if topping.Name=='Dough' then
							killPizza()
						end
					elseif pizza_cook_table[state].handler then
						pizza_cook_table[state].handler(topping, plr)
					end
				end
			end
		end)
		
	end
end

--========================================================================================
-- End  Interaction handler functions
--========================================================================================



--========================================================================================
-- BEGIN  Module Build
--========================================================================================


local interactions={	-- Dictionary for handler functions according to the type of interactive station player is at
	Add = pickUp,
	Sub = trashTool,
	Mixer = useMixer,
	Cut = zeBoard,
	PizzaOven = pizzaz,
}

local function killInteract(plr)

	local action_data = playerStore[plr.UserId].actions
	action_data.coroutine=coroutine.running()
	
	if action_data.connection and action_data.connection.Connected then
		action_data.connection:Disconnect()
		action_data.connection=nil
	end
	if action_data.callback then
		action_data.callback = action_data.callback()
	end
	
	action_data.status='ready'
end

local function interact(plr, modeObj, state)
	gameState = state or gameState
	
	local valid, _, process_time = checkContext(plr, modeObj)
	
	local mode = modeObj:FindFirstChild('Type')['Value']
	-- Add, Sub, Cut, Mix, POven, Oven, Open, Plate, Serve
	
	
	if interactions[mode] and valid then
		if playerStore[plr.UserId].actions.status=='running' then
			killInteract(plr)
		end
		
		playerStore[plr.UserId].actions.status='running'
		local success,err = pcall(function () 
			interactions[mode](plr, modeObj, process_time)
		end)
		if not success then
			print('INTERACTION ERROR',err)
		end
		playerStore[plr.UserId].actions.status='ready'
	end
	
	return playerStore[plr.UserId].score.submitted, getFinalScore(plr.UserId, true)
end





if runService:IsServer() then	-- SERVER CODE -----------------------------------------------------------
	-- Connect players to internal script data
	players.PlayerAdded:Connect(function (plr)
		if not isRunning() then
			return
		end
		playerStore[plr.UserId]= httpService:JSONDecode(httpService:JSONEncode(ps_Def))
		playerStore[plr.UserId].score.time.begin=gameState.clock
	end)
	
	players.PlayerRemoving:Connect(function (plr)
		playerStore[plr.UserId]= nil
	end)
	
	-- Functions
	recipe.sendScores=sendScores
	recipe.interact=interact
	recipe.killInteract=killInteract
	recipe.loadIngredients=loadIngredients
     
else -- CLIENT CODE ------------------------------------------------------------------------------------
	-- Events
	RECIPE_SIG.OnClientEvent:Connect(displayScores)
	
	-- Functions
	recipe.checkContext=checkContext
	recipe.displayRecipe=displayRecipe
	
end -- END CLIENT CODE ---------------------------------------------------------------------------------


local function new(state)
	RECIPE_CONTROL:Fire(id)
	
	if runService:IsServer() then
		-- Setup
		gameState=state
		for _,plr in pairs(players:GetPlayers()) do
			playerStore[plr.UserId]= httpService:JSONDecode(httpService:JSONEncode(ps_Def))
			playerStore[plr.UserId].score.time.begin=gameState.clock
		end	
	end
	return recipe
end
recipe.new=new


return recipe