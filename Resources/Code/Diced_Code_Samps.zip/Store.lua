-- Player datastore Systems
-- DICED by Plated Studios

-- Gavin Zimmerman

-- API Dependencies
local players=game:GetService('Players')
local dataStoreService=game:GetService('DataStoreService')
local serverStorage=game:GetService('ServerStorage')
local repStorage=game:GetService('ReplicatedStorage')
local market=game:GetService('MarketplaceService')
local httpService=game:GetService('HttpService')
local runService=game:GetService('RunService')

-- Signal Endpoints
local connections=repStorage:FindFirstChild('Connections')
local REWARD_ENDPOINT=connections:FindFirstChild('REWARD_ENDPOINT')
local POINT_SIGNAL=connections:FindFirstChild('POINT_SIGNAL')
local S_SKILL_HANDLER = connections:FindFirstChild('SKILL_SERVER_HANDLER')
local C_SKILL_HANDLER = connections:FindFirstChild('SKILL_CLIENT_HANDLER')
local S_VIP_HANDLER = connections:FindFirstChild('VIP_SERVER_HANDLER')
local C_VIP_HANDLER = connections:FindFirstChild('VIP_CLIENT_HANDLER')
local UPGRADE_ENDPOINT = connections:FindFirstChild('UPGRADE_ENDPOINT')
local REVIVE_HANDLER = connections:FindFirstChild('REVIVE_HANDLER')
local GET_PLAYERDATA_SERVER = connections:FindFirstChild('GET_PLAYERDATA_SERVER')
local SET_PLAYERDATA = connections:FindFirstChild('SET_PLAYERDATA')
local CONFIRM_SIG = connections:FindFirstChild('CONFIRM_SIG')
local CLOCK_SIG = connections:FindFirstChild('CLOCK_SIG')

-- Configurables
local vipGamepassId = 7445030
local vipPromotion = true		 		-- Free VIP to players on join; special beta promotion
local points = {30, 60, 90, 120, 200} 	-- Base points per consecutive day

local version=2

local startingStats={
	points=50,
	wins=0,
	logs = {				-- Used with daily visits and rewards
		consecutive=0,
		last_point=-1,
		ad_point=0
	},
	conditions = {
		vip = vipPromotion,
		revive = false,			-- True if player purchased a revival which was not redeemed
		map = 0,			-- True if player purchased a map selection which was never played
		recipe = 0			-- True if player purchased a recipe selection which was never played
	},
	upgrades = {
		MixerLvl=1,
		CutLvl=1,
		CookLvl=1,
		DashLvl=1
	}
}


-- Internal Global Vars (static)
local dataStore = dataStoreService:GetDataStore("PlayerStats",'Version'..version)
local playerStore={}


-- Player Data Functions
local function getData(id, depth)
	--print('Loading data for id',id)
	local depth = depth or 1
	
	local success, err
	success, err, playerStore[id].status, playerStore[id].data = pcall(function ()
		local isLoading=playerStore[id].status=='loading'
		if not isLoading then
			return nil, 'cancelled'
		end
		
		local data=dataStore:GetAsync('User_'..id) or httpService:JSONDecode(httpService:JSONEncode(startingStats))
		
		isLoading = playerStore[id].status=='loading'
		local status = (isLoading and 'ok') or 'cancelled'
		
		return nil, status, isLoading and data
	end)
	playerStore[id].status=playerStore[id].status or 'loading'
	
	
	if not success then
		print('DATASTORE LOAD ERROR:\n  '..err)
		wait(math.pow(depth,1.8))
		
		return getData(id, depth+1)
	end
	-- Set vip with vip promotion
	playerStore[id].data.conditions.vip = playerStore[id].data.conditions.vip or vipPromotion

	--print('Player data loaded for plr id: '..id)
	return 0
end

local function saveData(id, depth)
	--print('Saving data for plr id: '..id)
	local success, err
	success, err, playerStore[id].status = pcall(function ()
		dataStore:SetAsync('User_'..id, playerStore[id].data)
		return 'ok'
	end)
	
	if not success then
		print('DATASTORE SAVE ERROR\n'..err)
		wait(math.pow(depth,1.8))
		return saveData(id, depth+1)
	end
	
	--print('Data saved')
	return 0
end

players.PlayerAdded:Connect(function (plr)
	playerStore[plr.UserId]={ -- Init
		status = 'loading',
		data = nil
	}
	getData(plr.UserId) -- Load
	
	if playerStore[plr.UserId]=='cancelled' then
		playerStore[plr.UserId]=nil
		return
	end
	
	local stat= Instance.new("Folder")
		stat.Name="leaderstats"
		stat.Parent=plr
	
	local pts=Instance.new("IntValue")
		pts.Name="Points"
		pts.Value=playerStore[plr.UserId].data.points
		pts.Parent=stat
	
	local wins=Instance.new("IntValue")
		wins.Name="Wins"
		wins.Value=playerStore[plr.UserId].data.wins
		wins.Parent=stat
end)

players.PlayerRemoving:Connect(function (plr)
	if playerStore[plr.UserId].status~='ok' then
		playerStore[plr.UserId].status='terminate'
		return
	end
	
	playerStore[plr.UserId].status='saving'
	saveData(plr.UserId)
	playerStore[plr.UserId]=nil
end)


-- Yield on game if data is not stored yet
game:BindToClose(function ()
	while not runService:IsStudio() and #playerStore>0 do
		wait(1)
	end
end)




-- Marketplace Functions
-- Positive return values correspond to day of consecutive visits; edge cases are negative and defined as
ERROR = -1
INIT = -3
ADVERT=-2
local function getRewardCode(id)
	if not playerStore[id] then
		return ERROR	-- Return error
	end
	
	local logs = playerStore[id].data.logs
	if logs.last_point==-1 then
		logs.last_point=0
		return INIT
	end
	
	if os.time()-logs.last_point>=86400 then -- Return consecutive day for reward
		if os.time()-logs.last_point>172800 then
			return 1
		else
			return (logs.consecutive%5)+1
		end
		
	elseif os.time()-logs.ad_point>=2700 then	-- Return advertisement
		logs.ad_point=os.time()
		return ADVERT
	end
	
	return 0
end


local function rewardPoints(plr, attr, x)
	playerStore[plr.UserId].data[attr]=playerStore[plr.UserId].data[attr]+ (x or 0)
	
	plr:FindFirstChild('leaderstats').Points.Value = playerStore[plr.UserId].data.points
	plr:FindFirstChild('leaderstats').Wins.Value = playerStore[plr.UserId].data.wins
end


-- Helper Func; polls till playerdata has loaded
local function waitOn(id)
	while not playerStore[id] or playerStore[id].status~='ok' do
		runService.Heartbeat:Wait()
	end
end


local function getSkillCost(lvl)
	return 200 + (80 * math.pow(lvl+1,2))
end


-- Retrieves vip status of plr
local function checkVIP(plr)
	waitOn(plr.UserId)
	return (playerStore[plr.UserId].data.conditions.vip or market:UserOwnsGamePassAsync(plr.UserId, vipGamepass))
end
S_VIP_HANDLER.OnInvoke = checkVIP -- Connect to server endpoint
C_VIP_HANDLER.OnServerInvoke = checkVIP -- Connect to client endpoint


-- Retrieves skill array of plr
local function getSkills(plr)
	waitOn(plr.UserId)
	return playerStore[plr.UserId].data.upgrades
end
S_SKILL_HANDLER.OnInvoke= getSkills -- Connect to server endpoint
C_SKILL_HANDLER.OnServerInvoke = getSkills -- Connect to client endpoint



-- Used to get reward data 
REWARD_ENDPOINT.OnServerInvoke = (function(plr, RequestType)
	-- Get reward points array
	local pointArray = points
	if checkVIP(plr) then
		local newArray={}
		for i,v in pairs(points) do
			newArray[i]=v*2
		end
		pointArray=newArray
	end
	
	if RequestType=='GET' then
		waitOn(plr.UserId)
		return getRewardCode(plr.UserId), pointArray
		
	elseif RequestType=='POST' and playerStore[plr.UserId].status=='ok' then
		if getRewardCode(plr.UserId)>0 then
			rewardPoints(plr, 'points', pointArray[getRewardCode(plr.UserId)])
			
			playerStore[plr.UserId].data.logs.consecutive=getRewardCode(plr.UserId)
			playerStore[plr.UserId].data.logs.last_point=os.time()
			return 'ACK'
		end
	end
	
	return 'ERROR'
end)

-- Reward points/ wins
POINT_SIGNAL.Event:Connect(function (plr, attr ,points)
	if not (plr and points and typeof(playerStore[plr.UserId].data[attr])=='number') then
		return
	end
	if attr=='points' then
		if checkVIP(plr) then
			points=points*1.25
		end
		if market:UserOwnsGamePassAsync(plr.UserId, 7484693) then
			points=points*2
		end
	end
	
	rewardPoints(plr,attr,points)
end)

UPGRADE_ENDPOINT.OnServerInvoke = (function (plr, request, attr)
	if request=='GET' then	-- Get skill cost
		local returnArray = {}
		for i,v in pairs(playerStore[plr.UserId].data.upgrades) do
			returnArray[i]=getSkillCost(v+1)
		end
		
		return returnArray
		
	elseif request=='POST' then	-- Buy
		if playerStore[plr.UserId].data.upgrades[attr] then
			
			local cost = getSkillCost(playerStore[plr.UserId].data.upgrades[attr]+1)
			if playerStore[plr.UserId].data.points>=cost and playerStore[plr.UserId].data.upgrades[attr]<5 then
				rewardPoints(plr,'points',-cost)
				playerStore[plr.UserId].data.upgrades[attr]=playerStore[plr.UserId].data.upgrades[attr]+1
			end
		end
		
		return playerStore[plr.UserId].data.upgrades[attr], getSkillCost(playerStore[plr.UserId].data.upgrades[attr]+1)
	end
end)


GET_PLAYERDATA_SERVER.OnInvoke = (function (id)
	if not (playerStore[id] and playerStore[id].data) then
		return
	end
	waitOn(id)
	
	return playerStore[id].data
end)

SET_PLAYERDATA.Event:Connect(function (id, data)
	if not (playerStore[id] and playerStore[id].data) then
		return
	end
	playerStore[id].data=data
end)



-- Handle Purchasable content
local productHandlers= {}

function getRewardPlrWith(points)
	return (
		function (reciept, plr)
			rewardPoints(plr, 'points', points)
			return true
		end
	)
end

productHandlers[880770464] = getRewardPlrWith(50)	-- 50 Currency
productHandlers[880771550] = getRewardPlrWith(100)	-- 100 Currency
productHandlers[880773114] = getRewardPlrWith(500)	-- 500 Currency
productHandlers[880774774] = getRewardPlrWith(1000)	-- 1000 Currency


productHandlers[880768746] = function(receipt, player)	-- Pause the Clock
	CLOCK_SIG:Fire(22)
	return true -- granted
end


productHandlers[945585056] = function(receipt, player)	-- Player revival
	local check=REVIVE_HANDLER:Invoke(player.UserId)		-- Checks with main if request is valid; if valid main sends back player currently on losing docket; returns nil otherwise
	
	if check==player then
		return true -- granted
	else
		if playerStore[player.UserId] then
			playerStore[player.UserId].data.conditions.revive=true
			return true
		end
	end
	return false
end


productHandlers[945585237]= function(recipt,player)	-- Map request
	CONFIRM_SIG:Fire(player.UserId, 'Map')
	playerStore[player.UserId].data.conditions.map=playerStore[player.UserId].data.conditions.map+1
	
	return true
end

productHandlers[945585386]= function(recipt,player)	-- Recipe request
	CONFIRM_SIG:Fire(player.UserId, 'Recipe')
	playerStore[player.UserId].data.conditions.recipe=playerStore[player.UserId].data.conditions.recipe+1
	
	return true
end



local purchaseHistoryStore = dataStoreService:GetDataStore("PurchaseHistory")
local function processReceipt(receiptInfo)
	-- Determine if the product was already granted by checking the data store  
	local playerProductKey = receiptInfo.PlayerId .. "_" .. receiptInfo.PurchaseId
	
	local purchased
	local success, errorMessage = pcall(function()
		purchased = purchaseHistoryStore:GetAsync(playerProductKey)
	end)
	
	-- If purchase was recorded, the product was already granted
	if success and purchased then
		return Enum.ProductPurchaseDecision.PurchaseGranted
	elseif not success then
		error("Data store error:" .. errorMessage)
	end
 
	-- Find the player who made the purchase in the server
	local player = players:GetPlayerByUserId(receiptInfo.PlayerId)
	if not player then
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end
	
	-- Look up handler function from 'productFunctions' table above
	local handler = productHandlers[receiptInfo.ProductId]
 
	-- Call the handler function and catch any errors
	local success, result = pcall(handler, receiptInfo, player)
	if not success or not result then
		warn("Error occurred while processing a product purchase")
		print("\nProductId: ", receiptInfo.ProductId)
		print("\nPlayer: ", player)
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end
 
	-- Record transaction in data store so it isn't granted again
	local success, errorMessage = pcall(function()
		purchaseHistoryStore:SetAsync(playerProductKey, true)
	end)
	if not success then
		error("Cannot save purchase data: " .. errorMessage)
	end
 
	return Enum.ProductPurchaseDecision.PurchaseGranted
end

market.ProcessReceipt=processReceipt





