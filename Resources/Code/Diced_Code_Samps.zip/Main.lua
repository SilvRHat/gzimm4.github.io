-- Gameplay main structure
-- DICED by Plated Studios

-- Gavin Zimmerman


-- API Dependencies
local repStorage=game:GetService('ReplicatedStorage')
local players=game:GetService('Players')
local tweenService=game:GetService('TweenService')
local lighting=game:GetService('Lighting')
local marketPlace=game:GetService('MarketplaceService')
local runService=game:GetService('RunService')
local teleportService=game:GetService('TeleportService')

-- Signal Endpoints
local connections=repStorage:FindFirstChild('Connections')
local GUI_HANDLER=connections:FindFirstChild('GUI_HANDLER')
local GUI_SIGNAL=connections:FindFirstChild('GUI_SIGNAL')
local SKILL_HANDLER=connections:FindFirstChild('SKILL_SERVER_HANDLER')
local VIP_HANDLER=connections:FindFirstChild('VIP_SERVER_HANDLER')
local KILL_HANDLER=connections:FindFirstChild('KILL_HANDLER')
local INPUT_HANDLER=connections:FindFirstChild('INPUT_HANDLER')
local POINT_SIG=connections:FindFirstChild('POINT_SIGNAL')
local REVIVE_HANDLER = connections:FindFirstChild('REVIVE_HANDLER')
local REQUEST_HANDLER = connections:FindFirstChild('REQUEST_HANDLER')
local CONFIRM_SIG = connections:FindFirstChild('CONFIRM_SIG')
local GET_PLAYERDATA = connections:FindFirstChild('GET_PLAYERDATA_SERVER')
local SET_PLAYERDATA = connections:FindFirstChild('SET_PLAYERDATA')
local CLOCK_SIG = connections:FindFirstChild('CLOCK_SIG')


-- Configables
	-- Time
	local INTERMISSION_TIME= 10 			-- +3 (COUNTDOWN)
	local ROUND_TIME= 2 * (60) + 30	-- Formanted minutes (in seconds [*60]) + seconds
	local LOAD_TIME=10						-- Time for character to load 
	local DELAY_TIME= 5					-- Time between when all players are loaded and first intermission
	local SCORE_TIME=10

	-- Server
	local MIN_SERVER_SIZE = 2
	
	-- Dashing
	local BASE_SPEED = 4
	local BASE_DURATION = 1
	local COOLDOWN = 8
	

-- Internal Global vars (static)
local playerStore={}
local gameState={	-- Data to be reflected to client
	status = 'onload',
	displayText=nil,
	rcp_ = nil,	
	map_ = nil,	
	nextMap = nil,
	nextRcp = nil,
	clock=0,
	paused=0,
	round = 0
}

local rcp, map		-- Instances

local maps=repStorage:FindFirstChild('Maps')
local recipes=repStorage:FindFirstChild('Recipes')




--= Player joining/ exiting ==========================================================================--
players.PlayerAdded:Connect(function (plr)
	local stations=0
	for _,_ in pairs(playerStore) do stations+=1 end
	
	playerStore[plr.UserId]={
		status = 'loading',
		station = stations+1,
		scoreTotal=0,
		submitted=false
	}
	
	-- Character
	plr.CharacterAdded:Connect(function (char)
		local hum = char:FindFirstChild("Humanoid")
		hum.WalkSpeed = (walkEnabled and 16) or 0
	end)
	plr.OnTeleport:Connect(function (state, Id)
		if state==Enum.TeleportState.Failed then					-- If teleport fails, then a kick is executed instead
			print("Failed to teleport player back to main lobby")
			plr:Kick("Teleport Failed: \n Please rejoin")
		end
	end)
	
	wait(LOAD_TIME)
	if playerStore[plr.UserId].status=='loading' then
		playerStore[plr.UserId].status='long_loading'	-- Don't yield to players taking longer to load
	end
end)


players.PlayerRemoving:Connect(function (plr)
	playerStore[plr.UserId].status='not_playing'
end)

GUI_HANDLER.OnServerInvoke = (function (plr)
	playerStore[plr.UserId].status='ok'		-- Signal that player's client is loaded
	return gameState, playerStore[plr.UserId].station		-- Returns player's station and gameState
end)




--= Player input ==========================================================================--

local function getRewardPointsFor(title)
	if title=='Winner' then
		return 15 * math.pow(2, gameState.round)
	end
	return 5 * math.pow(2, gameState.round)
end



local walkEnabled=false
local runDebounce={}
local function toggleWalkspeed(val)
	walkEnabled=val
	
	local plrList = players:GetPlayers()
	for _,plr in pairs(plrList) do
		if not plr.Character or not plr.Character:FindFirstChild('Humanoid') then
			continue
		end
		plr.Character.Humanoid.WalkSpeed = (walkEnabled and 16) or 0
		runDebounce[plr.UserId] = runDebounce[plr.UserId] and val
	end
end




local function getDash(player)		-- Returns dash speed Increase and duration
	local spI, dur = BASE_SPEED, BASE_DURATION
	local skillLvl=SKILL_HANDLER:Invoke(player)["DashLvl"]
	local vip= VIP_HANDLER:Invoke(player)
	
	hasSpeedIncrease = marketPlace:UserOwnsGamePassAsync(player.UserId, 7484700)
	hasSpeedExtend = marketPlace:UserOwnsGamePassAsync(player.UserId, 7484696)
	
	if hasSpeedIncrease or vip then
		spI=spI*2
	end
	if hasSpeedExtend or vip then
		dur=dur*2
	end
	
	sp+= (BASE_SPEED * (.6+(skillLvl*.2)))
	dur+= (BASE_DURATION * (.6+(skillLvl*.2)))
	return spI, dur
end


local function onInput(plr, input, passedTarget)
	if not (plr.Character:FindFirstChild("Humanoid")) then
		return
	end
	local char=plr.Character
	local hum=char:FindFirstChild("Humanoid")
	
	if input=='INTERACT' and passedTarget then
		local stationVal = passedTarget:FindFirstChild("Station")
		if stationVal and stationVal.Value~=playerStore[plr.UserId].station then
			return
		end
		
		playerStore[plr.UserId].submitted, playerStore[plr.UserId].scoreTotal = 
			rcp.interact(plr, passedTarget, gameState)
		
	elseif input=='DASH' and walkEnabled then
		if runDebounce[plr.UserId] then
			return
		end
		
		runDebounce[plr.UserId]=true
		local speed,duration=getDash(plr)
		
		hum.WalkSpeed=hum.WalkSpeed+speed
		wait(duration)
		if not runDebounce[plr.UserId] then
			return
		end
		
		hum.WalkSpeed= 16
		wait(COOLDOWN)
		runDebounce[plr.UserId]=nil
	end
end


KILL_HANDLER.OnServerInvoke= function (plr)
	if rcp then
		rcp.killInteract(plr)
	end
end






--= Incoming Signal Handlers ==========================================================================--
CLOCK_SIG.Event:Connect(function (t)
	gameState.paused=gameState.paused + (t or 0)
	GUI_SIGNAL:FireAllClients(gameState)
end)



local mapRequests={}		-- Current requests for map; prompt sent; but not processed
local rcpRequests={}		-- Current requests for recipe; prompt sent but not processed
CONFIRM_SIG.Event:Connect(function (plr, product)
	if product=='Map' and not gameState.nextMap and mapRequests[plr] then
		gameState.nextMap = {
			map = mapRequests[plr],
			plrId = plr
		}
		
	elseif product=='Recipe' and not gameState.nextRcp and rcpRequests[plr] then
		gameState.nextRcp = {
			rcp = rcpRequests[plr],
			plrId = plr
		}
	end
	
	GUI_SIGNAL:FireAllClients(gameState)
end)


REQUEST_HANDLER.OnServerInvoke = function (player, attr, selection)
	if not (attr=='map' or attr=='recipe') then
		return nil
	end
	
	local hasRedeem= GET_PLAYERDATA:Invoke(player.UserId).conditions[attr]
	if attr=='map' then
		if gameState.map_.plrId==player.UserId then
			return
		end
		
		if selection and selection.Parent==maps then
			mapRequests[player.UserId]=selection
			if hasRedeem then
				CONFIRM_SIG:Fire(player.UserId,'Map')
			end
		end
	
	elseif attr=='recipe' then
		if gameState.rcp_.plrId==player.UserId then
			return nil
		end
		
		if selection and selection.Parent==recipes then
			rcpRequests[player.UserId]=selection
			if hasRedeem then
				CONFIRM_SIG:Fire(player.UserId,'Recipe')
			end
		end
	end
	
	return hasRedeem>0
end




--= Game Cycle Functions ==========================================================================--

-- Wait to begin game until enough players are in
local yeildToPlayerLoad
yeildToPlayerLoad = function()
	gameState.status='waiting on plrs'
	gameState.displayText='Loading'
	while true do
		local total, ready = 0,0
		for i,player in pairs(playerStore) do
			total=total+1
			
			if player.status~='loading' then
				ready=ready+1
			end
		end
		if total>=MIN_SERVER_SIZE and total==ready then
			break
		end
		
		wait(.25)
	end
	wait(DELAY_TIME)
	
	yeildToPlayerLoad = (function()
		return 0 -- Do nothing on future function references
	end)
end



local function setup()
	lighting.Blur.Size=20
	math.randomseed(os.time())
end



-- Setup required resources to play new round
local function miseEnPlace()
	-- Cleanup previous map
	if map and rcp then
		map:Destroy()
	end
	gameState.round=gameState.round+1
	
	-- Choose map
	local maps=maps:GetChildren()
	gameState.map_ = players:GetPlayerByUserId((gameState.nextMap or {plrId=0}).plrId) and gameState.nextMap or {
		map = maps[math.random(#maps)]
	}
	-- Choose recipes
	local recipes=recipes:GetChildren()
	gameState.rcp_ = players:GetPlayerByUserId((gameState.nextRcp or {plrId=0}).plrId) and gameState.nextRcp or {
		rcp = recipes[math.random(#recipes)]
	}
	
	-- Reset
	gameState.nextMap = nil
	gameState.nextRcp = nil
	gameState.clock=ROUND_TIME
	
	-- Load map/ recipe
	map=gameState.map_.map:FindFirstChild("Map"):Clone()
	rcp=require(gameState.rcp_.rcp.CardX).new(gameState)
	
	-- Load map
	map.Parent=workspace
	rcp.loadIngredients(map)
	
	-- Load players
	local plrList=players:GetPlayers()
	for _,plr in pairs(plrList)do
		plr:LoadCharacter()
	end
end

-- Intermission
local function intermisso()	
	gameState.status='intermission'
	gameState.displayText="Intermission"
	gameState.clock=INTERMISSION_TIME
	
	coroutine.wrap(function ()
		while gameState.status=='intermission' or gameState.status=='intermission_ending' do
			gameState.clock=gameState.clock-1
			wait(1)
		end
	end)()
	
	
	GUI_SIGNAL:FireAllClients(gameState)	-- Updates players
	wait(INTERMISSION_TIME-3)
	
	-- sends signal state 2
	gameState.displayText=nil
	gameState.status='intermission_ending'
	GUI_SIGNAL:FireAllClients(gameState)
	
	-- Countdown
	wait(1) 
	local tween = tweenService:Create(lighting.Blur, TweenInfo.new(2, Enum.EasingStyle.Linear), {Size=0})
	tween:Play()
	wait(3)
end

-- Game Round
local function onTheFly()
	gameState.status='gameplay'
	gameState.clock=ROUND_TIME
	
	GUI_SIGNAL:FireAllClients(gameState)
	
	for id, data in pairs(playerStore) do
		data.scoreTotal=0
		data.submitted=false
	end
	
	toggleWalkspeed(true)
	INPUT_HANDLER.OnServerInvoke = onInput
	
	-- Check if player who bought map is still in game, if they are then mark purchase complete
	if players:GetPlayerByUserId(gameState.map_.plrId or 0) then
		local data = GET_PLAYERDATA:Invoke(gameState.map_.plrId)
		
		if data and data.conditions then
			data.conditions.map=data.conditions.map-1
			SET_PLAYERDATA:Fire(gameState.map_.plrId, data)
		end
		gameState.map_.plrId=nil
	end
	if players:GetPlayerByUserId(gameState.rcp_.plrId or 0) then
		local data = GET_PLAYERDATA:Invoke(gameState.rcp_.plrId)
		
		if data and data.conditions then
			data.conditions.recipe=data.conditions.recipe-1
			SET_PLAYERDATA:Fire(gameState.rcp_.plrId, data)
		end
		gameState.rcp_.plrId=nil
	end
	
	
	-- Round process
	while true do
		
		local total, submitted = 0,0
		for id, data in pairs(playerStore) do
			if data.status=='ok' or data.status=='long_loading' then
				total=total+1
				if data.submitted==true then
					submitted=submitted+1
				end
			end
		end
		
		if gameState.paused>0 then
			gameState.paused=gameState.paused-1
		else
			gameState.clock=gameState.clock-1
			
			if gameState.clock%15==0 then
				GUI_SIGNAL:FireAllClients(gameState)
			end
		end
		
		if submitted==total or (gameState.clock<=0 and gameState.paused<=0) then
			break
		end
		
		wait(1)
	end
	
	INPUT_HANDLER.OnServerInvoke=(function() return end)
	toggleWalkspeed(false)
	
	local tween = tweenService:Create(lighting.Blur, TweenInfo.new(2, Enum.EasingStyle.Linear), {Size=20})
	tween:Play()
	gameState.paused=0
end

-- Grading and Rewards
local function heatOff()
	gameState.status='grading'
	GUI_SIGNAL:FireAllClients(gameState)
	
	local low= math.huge
	local high= -math.huge
	local highWinner, lowLoser
	rcp.sendScores(SCORE_TIME)
	
	-- Get scores
	for id, data in pairs(playerStore) do
		if data.status~='ok' and not players:GetPlayerByUserId(id) then
			continue
		end
		
		if data.scoreTotal>high then
			high=data.scoreTotal
			highWinner=id
		end
		if data.scoreTotal<low then
			low=data.scoreTotal
			lowLoser=id
		end
	end
	
	wait(SCORE_TIME)
	
	local cont = (#players:GetPlayers()-1>=MIN_SERVER_SIZE)
	
	-- Give out rewards
	for id, data in pairs(playerStore) do
		if id==highWinner and data.submitted==true then		-- Player won round; is safe
			POINT_SIG:Fire(players:GetPlayerByUserId(id), 'points', getRewardPointsFor('Winner'))
			if not cont then
				POINT_SIG:Fire(players:GetPlayerByUserId(id), 'wins', 1)
			end
			
		elseif id==lowLoser then	-- Player lost round; gets the boot
			local data=GET_PLAYERDATA:Invoke(id)
			
			if cont and not (data and data.conditions.revive) then
				coroutine.wrap(promptRevive)(id)
			elseif (data and data.conditions.revive) then
				data.conditions.revive=false
				SET_PLAYERDATA(id, data)
			end
			
		elseif data.submitted==true then	-- Player submitted something that wasn't bad
			POINT_SIG:Fire(players:GetPlayerByUserId(id), 'points', getRewardPointsFor())
		end
	end
	
	wait(2)
	return cont
end


-- Round
setup()
while true do
	miseEnPlace()
	
	-- Wait on players
	yeildToPlayerLoad()
	
	-- Begin intermission phase
	intermisso()
	
	-- Begin round phase
	onTheFly()
	
	-- Begin grading phase
	if not heatOff() then
		break
	end
end

gameState.status='ending'
GUI_SIGNAL:FireAllClients(gameState)

print('Round sequence concluded; game ending soon')
teleportService:TeleportPartyAsync(3600833945,players:GetPlayers())


