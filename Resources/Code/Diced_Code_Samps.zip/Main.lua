-- Main; All round-player interaction relations
-- V2.2; main.lua
-- Gavin Zimmerman | Written for Diced by Plated Studios
-- 07/16/2020



-- API Services
local repStorage=game:GetService('ReplicatedStorage')
local players=game:GetService('Players')
local tweenService=game:GetService('TweenService')
local lighting=game:GetService('Lighting')
local marketPlace=game:GetService('MarketplaceService')
local runService=game:GetService('RunService')
local teleportService=game:GetService('TeleportService')

-- Script Connections/ Dependencies
local connections=repStorage:FindFirstChild('Connections')
local GUI_HANDLER=connections:FindFirstChild('GUI_HANDLER')
local GUI_SIGNAL=connections:FindFirstChild('GUI_SIGNAL')
local SKILL_HANDLER=connections:FindFirstChild('SKILL_SERVER_HANDLER')
local VIP_HANDLER=connections:FindFirstChild('VIP_SERVER_HANDLER')
local KILL_HANDLER=connections:FindFirstChild('KILL_HANDLER')
local INPUT_HANDLER=connections:FindFirstChild('INPUT_HANDLER')
local POINT_SIG=connections:FindFirstChild('POINT_SIGNAL')
local REVIVE_HANDLER = connections:FindFirstChild('REVIVE_HANDLER')
local REQUEST_HANDLER = connections:FindFirstChild('REQUEST_HANDLER')
local CONFIRM_SIG = connections:FindFirstChild('CONFIRM_SIG')
local GET_PLAYERDATA = connections:FindFirstChild('GET_PLAYERDATA_SERVER')
local SET_PLAYERDATA = connections:FindFirstChild('SET_PLAYERDATA')
local CLOCK_SIG = connections:FindFirstChild('CLOCK_SIG')


-- Local variables/ script store
local playerStore={}
local gameState={	-- Data to be reflected to client
	status = 'onload',
	displayText=nil,
	rcp_ = nil,	
	map_ = nil,	
	nextMap = nil,
	nextRcp = nil,
	clock=0,
	paused=0,
	round = 0
}

local rcp, map		-- Instances

local mapRequests={}		-- Current requests for map; prompt sent; but not processed
local rcpRequests={}		-- Current requests for recipe; prompt sent but not processed

local maps=repStorage:FindFirstChild('Maps')
local recipes=repStorage:FindFirstChild('Recipes')


-- Configurations 
	-- Time
	local INTERMISSION_TIME= 10 			-- +3 (COUNTDOWN)
	local ROUND_TIME= (2) *60	+	(30)	-- Formanted minutes (in seconds [*60]) + seconds
	local LOAD_TIME=10						-- Time for character to load 
	local DELAY_TIME= 5					-- Time between when all players are loaded and first intermission
	local SCORE_TIME=10

	-- Server
	local minServerSize = 2




local function getRewardPointsFor(priority)
	if priority=='Winner' then
		return 15 * math.pow(2, gameState.round)
	end
	return 5 * math.pow(2, gameState.round)
end


math.randomseed(os.time())

local walkEnabled=false
local runDebounce={}

local function toggleWalkspeed(val)
	walkEnabled=val
	
	local plrList = players:GetPlayers()
	for i,plr in pairs(plrList) do
		if not plr.Character or not plr.Character:FindFirstChild('Humanoid') then
			continue
		end
		plr.Character.Humanoid.WalkSpeed = (walkEnabled and 16) or 0
		runDebounce[plr.UserId] = runDebounce[plr.UserId] and val
	end
end




local function getDash(player)		-- Returns dash speed Increase and duration
	local baseSpeed = 4
	local baseDuration = 1
	
	local spI=baseSpeed
	local dur=baseDuration
	local skillLvl=SKILL_HANDLER:Invoke(player)["DashLvl"]
	
	local vip= VIP_HANDLER:Invoke(player)
	if (marketPlace:UserOwnsGamePassAsync(player.UserId, 7484700)) or vip==true then
		spI=spI*2
	end
	if (marketPlace:UserOwnsGamePassAsync(player.UserId, 7484696)) or vip==true then
		dur=dur*2
	end
	
	spI=spI+ (baseSpeed * (.6+(skillLvl*.2)))
	dur=dur+ (baseDuration * (.6+(skillLvl*.2)))
	return spI,dur
end





players.PlayerAdded:Connect(function (plr)
	local stations=0
	for i,v in pairs(playerStore) do stations=stations+1 end
	
	playerStore[plr.UserId]={
		status = 'loading',
		station = stations+1,
		scoreTotal=0,
		submitted=false
	}
	
	-- Character
	plr.CharacterAdded:Connect(function (char)
		local hum = char:FindFirstChild("Humanoid")
		hum.WalkSpeed = (walkEnabled and 16) or 0
	end)
	plr.OnTeleport:Connect(function (state, Id)
		if state==Enum.TeleportState.Failed then					-- If teleport fails, then a kick is executed instead
			print("Failed to teleport player back to main lobby")
			plr:Kick("Teleport Failed: \n Please rejoin")
		end
	end)
	
	
	-- For yieldToPlayerLoad
	wait(LOAD_TIME)
	if playerStore[plr.UserId].status=='loading' then
		playerStore[plr.UserId].status='long_loading'
	end
end)

players.PlayerRemoving:Connect(function (plr)
	playerStore[plr.UserId].status='not_playing'
end)

GUI_HANDLER.OnServerInvoke = (function (plr)
	playerStore[plr.UserId].status='ok'		-- Signal that player's client is loaded
	return gameState, playerStore[plr.UserId].station		-- Returns player's station and gameState
end)




local function onInput(plr, input, passedTarget)
	if not (plr.Character:FindFirstChild("Humanoid")) then
		return 'No humanoid'
	end
	local char=plr.Character
	local hum=char:FindFirstChild("Humanoid")
	
	if input=='INTERACT' and passedTarget then
		local stationVal = passedTarget:FindFirstChild("Station")
		if stationVal then
			if stationVal.Value~=playerStore[plr.UserId].station then
				return 'Station invalid'
			end
		end
		
		playerStore[plr.UserId].submitted, playerStore[plr.UserId].scoreTotal = rcp.interact(plr, passedTarget, gameState)
		
	elseif input=='DASH' and walkEnabled then
		if runDebounce[plr.UserId] then
			return
		end
		runDebounce[plr.UserId]=true
		local speed,duration=getDash(plr)
		
		hum.WalkSpeed=hum.WalkSpeed+speed
		
		wait(duration)
		if not runDebounce[plr.UserId] then
			return
		end
		hum.WalkSpeed= 16
		wait(8)
		runDebounce[plr.UserId]=nil
		
	end
	
	return 'ok'
end

KILL_HANDLER.OnServerInvoke= function (plr)
	if rcp then
		rcp.killInteract(plr)
	end
end






function nilFunc()
	return nil
end
REVIVE_HANDLER.OnInvoke = nilFunc

local function promptRevive(id)
	local revived=false
	
	REVIVE_HANDLER.OnInvoke = function ()
		if players:GetPlayerByUserId(id) and gameState~='ending' then
			revived=true
			REVIVE_HANDLER.OnInvoke = nilFunc
			
			-- Execute revive
			GUI_SIGNAL:FireClient(players:GetPlayerByUserId(id), gameState, 'revive_ok')
			
			return players:GetPlayerByUserId(id)
		end
	end
	
	GUI_SIGNAL:FireClient(players:GetPlayerByUserId(id), gameState, 'revive', INTERMISSION_TIME)
	
	wait(INTERMISSION_TIME+2)	
	
	REVIVE_HANDLER.OnInvoke = nilFunc
	if revived or not players:GetPlayerByUserId(id) then
		return
	end
	print("Time window has closed; last losing player is queued for teleport; Player- "..id)
	
	GUI_SIGNAL:FireClient(players:GetPlayerByUserId(id), gameState, 'ending')
	
	if runService:IsStudio() then
		players:GetPlayerByUserId(id):Kick("Cannot teleport in studio")		-- For studio tests
	else
		teleportService:Teleport(3600833945, players:GetPlayerByUserId(id))	-- Teleports player
	end
end


CLOCK_SIG.Event:Connect(function (t)
	gameState.paused=gameState.paused + (t or 0)
	GUI_SIGNAL:FireAllClients(gameState)
end)



CONFIRM_SIG.Event:Connect(function (id, product)
	if product=='Map' and not gameState.nextMap and mapRequests[id] then
		print('Map Selected', mapRequests[id].Name)
		gameState.nextMap = {
			map = mapRequests[id],
			plrId = id
		}
		GUI_SIGNAL:FireAllClients(gameState, 'map')
		
	elseif product=='Recipe' and not gameState.nextRcp and rcpRequests[id] then
		print('Recipe Selected', rcpRequests[id].Name)
		gameState.nextRcp = {
			rcp = rcpRequests[id],
			plrId = id
		}
		GUI_SIGNAL:FireAllClients(gameState, 'recipe')
	end
end)

REQUEST_HANDLER.OnServerInvoke = function (player, attr, selection)
	if not (attr=='map' or attr=='recipe') then
		return false
	end
	local hasIt= GET_PLAYERDATA:Invoke(player.UserId).conditions[attr]
	if attr=='map' then
		if gameState.map_.plrId==player.UserId then
			hasIt=hasIt-1
		end
		
		if selection and selection.Parent==maps then
			mapRequests[player.UserId]=selection
			if hasIt then
				CONFIRM_SIG:Fire(player.UserId,'Map')
			end
		end
	end
	
	if attr=='recipe' then
		if gameState.rcp_.plrId==player.UserId then
			hasIt=hasIt-1
		end
		if selection and selection.Parent==recipes then
			rcpRequests[player.UserId]=selection
			if hasIt then
				CONFIRM_SIG:Fire(player.UserId,'Recipe')
			end
		end
	end
	
	return hasIt>0 and hasIt
end





-- Wait to begin game until enough players are in
local yeildToPlayerLoad
yeildToPlayerLoad = function()
	gameState.status='waiting on plrs'
	gameState.displayText='Loading'
	while true do
		local total, ready = 0,0
		for i,player in pairs(playerStore) do
			total=total+1
			
			if player.status~='loading' then
				ready=ready+1
			end
		end
		if total>=minServerSize and total==ready then
			break
		end
		wait(.25)
		
	end
	wait(DELAY_TIME)
	
	yeildToPlayerLoad = (function()
		return 0 -- Do nothing on future function references
	end)
end



local function setup()
	lighting.Blur.Size=20
end



-- Setup required resources to play new round
local function miseEnPlace()
	-- Cleanup previous map
	if map and rcp then
		map:Destroy()
	end
	
	gameState.round=gameState.round+1
	
	-- Choose map
	local maps=maps:GetChildren()
	gameState.map_ = players:GetPlayerByUserId((gameState.nextMap or {plrId=0}).plrId) and gameState.nextMap or {
		map = maps[math.random(#maps)]
	}
	-- Choose recipes
	local recipes=recipes:GetChildren()
	
	gameState.rcp_ = players:GetPlayerByUserId((gameState.nextRcp or {plrId=0}).plrId) and gameState.nextRcp or {
		rcp = recipes[math.random(#recipes)]
	}
	gameState.nextMap = nil
	gameState.nextRcp = nil
	
	gameState.clock=ROUND_TIME
	
	-- Load map/ recipe
	map=gameState.map_.map:FindFirstChild("Map"):Clone()
	rcp=require(gameState.rcp_.rcp.CardX).new(gameState)
	
	-- Load map
	map.Parent=workspace
	rcp.loadIngredients(map)
	
	-- Load players
	local plrList=players:GetPlayers()
	for _,plr in pairs(plrList)do
		plr:LoadCharacter()
	end
	
	print('New round details chosen')
end

-- Intermission
local function intermisso()	
	gameState.status='intermission'
	gameState.displayText="Intermission"
	gameState.clock=INTERMISSION_TIME
	
	
	coroutine.wrap(function ()
		while gameState.status=='intermission' or gameState.status=='intermission_ending' do
			gameState.clock=gameState.clock-1
			wait(1)
		end
	end)()
	
	
	GUI_SIGNAL:FireAllClients(gameState)		-- Points to map, points to recipe, gives round rand Variation
	wait(INTERMISSION_TIME-3)
	
	-- sends signal state 2
	gameState.displayText=nil
	gameState.status='intermission_ending'
	GUI_SIGNAL:FireAllClients(gameState)
	
	-- Countdown
	wait(1) 
	local tween = tweenService:Create(lighting.Blur, TweenInfo.new(2, Enum.EasingStyle.Linear), {Size=0})
	tween:Play()
	wait(3)
end

-- Game Round
local function onTheFly()
	print('round')
	-- Round setup
	gameState.status='gameplay'
	gameState.clock=ROUND_TIME
	GUI_SIGNAL:FireAllClients(gameState)
	
	-- Check if player who bought map is still in game, if they are take away the purchase condition
	if players:GetPlayerByUserId(gameState.map_.plrId or 0) then	-- Map purchase redemtion
		local data = GET_PLAYERDATA:Invoke(gameState.map_.plrId)
		
		if data and data.conditions then
			data.conditions.map=data.conditions.map-1
			SET_PLAYERDATA:Fire(gameState.map_.plrId, data)
		end
		gameState.map_.plrId=nil
	end
	if players:GetPlayerByUserId(gameState.rcp_.plrId or 0) then	-- Recipe purchase redemtion
		local data = GET_PLAYERDATA:Invoke(gameState.rcp_.plrId)
		
		if data and data.conditions then
			data.conditions.recipe=data.conditions.recipe-1
			SET_PLAYERDATA:Fire(gameState.rcp_.plrId, data)
		end
		gameState.rcp_.plrId=nil
	end
	for id, data in pairs(playerStore) do
		data.scoreTotal=0
		data.submitted=false
	end
	
	toggleWalkspeed(true)
	
	INPUT_HANDLER.OnServerInvoke = onInput
	
	-- Round process
	while true do
		local total, submitted = 0,0
		for id, data in pairs(playerStore) do
			if data.status=='ok' or data.status=='long_loading' then
				total=total+1
				if data.submitted==true then
					submitted=submitted+1
				end
			end
		end
		if submitted==total then
			print('Submitted all')
			break
		end
		
		if gameState.paused>0 then
			gameState.paused=gameState.paused-1
		else
			gameState.clock=gameState.clock-1
			
			if gameState.clock==30 or gameState.clock==15 then
				GUI_SIGNAL:FireAllClients(gameState)
			end
		end
		
		if gameState.clock<=0 and gameState.paused<=0 then
			print('Time out')
			break
		end
		wait(1)
	end
	
	INPUT_HANDLER.OnServerInvoke=(function() return end)
	toggleWalkspeed(false)
	
	local tween = tweenService:Create(lighting.Blur, TweenInfo.new(2, Enum.EasingStyle.Linear), {Size=20})
	tween:Play()
	
	gameState.paused=0
end

-- Grading and Rewards
local function heatOff()
	gameState.status='grading'
	GUI_SIGNAL:FireAllClients(gameState)
	-- grading
	local low= math.huge
	local high= -math.huge
	local highWinner, lowLoser
	
	rcp.sendScores(SCORE_TIME)
	-- Get scores
	for id, data in pairs(playerStore) do
		if data.status~='ok' and not players:GetPlayerByUserId(id) then
			continue
		end
		
		if data.scoreTotal>high then
			high=data.scoreTotal
			highWinner=id
		end
		if data.scoreTotal<low then
			low=data.scoreTotal
			lowLoser=id
		end
	end
	
	wait(SCORE_TIME)
	
	local cont = (#players:GetPlayers()-1>=minServerSize)
	
	-- Give out rewards
	for id, data in pairs(playerStore) do
		if id==highWinner and data.submitted==true then		-- Player won round; is safe
			POINT_SIG:Fire(players:GetPlayerByUserId(id), 'points', getRewardPointsFor('Winner'))
			if not cont then
				POINT_SIG:Fire(players:GetPlayerByUserId(id), 'wins', 1)
			end
			
		elseif id==lowLoser then	-- Player lost round; gets the boot
			local data=GET_PLAYERDATA:Invoke(id)
			
			if cont and not (data and data.conditions.revive) then
				coroutine.wrap(promptRevive)(id)
			elseif (data and data.conditions.revive) then
				data.conditions.revive=false
				SET_PLAYERDATA(id, data)
			end
			
		elseif data.submitted==true then	-- Player submitted something that wasn't bad
			POINT_SIG:Fire(players:GetPlayerByUserId(id), 'points', getRewardPointsFor())
			
		end
	end
	
	wait(2)
	return cont
end


-- Round
setup()
while true do
	miseEnPlace()
	
	-- Wait on players
	yeildToPlayerLoad()
	
	-- Begin intermission phase
	intermisso()
	
	-- Begin round phase
	onTheFly()
	
	-- Begin grading phase
	if not heatOff() then
		break
	end
end

gameState.status='ending'
GUI_SIGNAL:FireAllClients(gameState)
print('Round sequence concluded; game ending soon')
teleportService:TeleportPartyAsync(3600833945,players:GetPlayers())