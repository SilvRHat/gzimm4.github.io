// Programming Assigment 3
// Operating Systems
// Gavin Zimmerman



#include "multi-lookup.h"
#include "util.h"



int main(int argc, char *argv[]) {
	int succ;
	pthread_attr_t attr;
	struct request_store* req_mem;
	struct req_thr_info* req_pool;
	struct resolve_store* res_mem;
	pthread_t *res_pool;
	struct buff_info* buffer;
	struct timeval start_time, finish_time;
	gettimeofday(&start_time, NULL);

	if (argc<5) 
		exit_err("Expected at least 4 arguments (<# request thr> <# resolve thr> <service txt file> <result txt file> [<input file>*])\n");
	
	int req_thr = min(atoi(argv[1]), MAX_REQUESTER_THREADS);
	int res_thr = min(atoi(argv[2]), MAX_RESOLVER_THREADS);

	if (req_thr<1) 
		exit_err("1st Argument invalid\n");
	
	else if (res_thr<1) 
		exit_err("2nd Argument invalid\n");
	
	FILE *fptr;
	fptr = fopen(argv[3],"w");
	if (fptr==NULL) 
		exit_err("3rd Argument invalid\n");
	fclose(fptr);
	
	fptr = fopen(argv[4],"w");
	if (fptr==NULL) 
		exit_err("4th Argument invalid\n");
	fclose(fptr);

	if (argv[3]==argv[4]) {
		exit_err("3rd and 4th Argument must be different file paths\n");
	}
	
	//printf("Number of requester threads is %d %s\n", req_thr, (req_thr==MAX_REQUESTER_THREADS)? "(MAX) ": "");
	//printf("Number of resolver threads is %d %s\n", res_thr, (res_thr==MAX_RESOLVER_THREADS)? "(MAX) ": "");
	
	succ = pthread_attr_init(&attr);
	if (succ<0) 
		exit_err("Thread attribute init failed\n");
	

	// Buffer
	buffer = malloc(sizeof(struct buff_info));
	buffer->size=0;
	buffer->buff = calloc(ARRAY_SIZE, sizeof(char*));
	for (int i=0; i<ARRAY_SIZE; i++) {
		buffer->buff[i]=NULL;
	}
	succ+=sem_init(&buffer->b_mutex, 0, 1);
	succ+=sem_init(&buffer->pr_ctr, 0, ARRAY_SIZE);
	succ+=sem_init(&buffer->cn_ctr, 0, 0);
	
	// Requesters
	req_mem = malloc(sizeof(struct request_store));
	succ+=sem_init(&req_mem->mutex, 0, 1);
	req_mem->files = &argv[5];
	req_mem->fmax = argc-5;
	req_mem->fi = 0;
	req_mem->buffer = buffer;
	req_mem->output=argv[3];

	req_pool= calloc(req_thr, sizeof(struct req_thr_info));

	// Resolvers
	res_mem = malloc(sizeof(struct resolve_store));
	succ+=sem_init(&res_mem->mutex, 0, 1);
	res_mem->buffer = buffer;
	res_mem->output = argv[4];

	res_pool= calloc(res_thr, sizeof(pthread_t));

	if (succ<0) {
		free(buffer);
		free(req_mem);
		free(res_mem);
		free(res_pool);
		free(req_pool);
		exit_err("Semaphore init failed\n");
	}
	
	
	// Create Request threads
	for (int i=0; i< req_thr; i++) {

		req_pool[i].shared=req_mem;
		
		succ = pthread_create(&req_pool[i].id, &attr, &requester, &req_pool[i]);

		if (succ<0)
			i=-1;
	}
	
	for (int i=0; i<res_thr; i++) {
		succ = pthread_create(&res_pool[i], &attr, &resolver, res_mem);
		
		if (succ<0)
			i=-1;
	}

	pthread_attr_destroy(&attr);
	
	
	// Wait on requester threads
	for (int i=0; i< req_thr; i++) {
		pthread_join(req_pool[i].id, NULL);
	}
	sem_post(&buffer->cn_ctr);
	free(req_mem);
	free(req_pool);

	// Wait on resolver threads
	for (int i=0; i< res_thr; i++) {
		pthread_join(res_pool[i], NULL);
	}
	free(res_mem);
	free(res_pool);


	free(buffer->buff);
	free(buffer);

	sem_destroy(&req_mem->mutex);
	sem_destroy(&res_mem->mutex);
	sem_destroy(&buffer->b_mutex);
	sem_destroy(&buffer->pr_ctr);
	sem_destroy(&buffer->cn_ctr);

	gettimeofday(&finish_time, NULL);
	printf("./multi-lookup: total time is %lf seconds\n", 
		((double)finish_time.tv_sec + ((double)finish_time.tv_usec/1000000)) - ((double)start_time.tv_sec + ((double)start_time.tv_usec/1000000)));

	return 0;
}





// Helpers
void exit_err(char *msg) {
	fprintf(stderr,"%s",msg);
	exit(-1);
}

int min(int a,int b ) {
	return (a<b)? a:b;
}




// Thread Logic
static void* requester(void *arg) {
	int serviced = 0; int current = 0;
	struct req_thr_info* self = arg;
	struct request_store* world = self->shared;

	FILE *fptr;
	char *input=NULL; size_t len=0;
	
	while (1) {
		// Select file
		sem_wait(&world->mutex);
		if (world->fi >= world->fmax) {
			FILE *output = fopen(world->output, "a");
			fprintf(output,"Thread %lx serviced %d files.\n", pthread_self(), serviced);

			fclose(output);
			sem_post(&world->mutex);
			break;
		}
		current = world->fi;
		world->fi+=1;
		sem_post(&world->mutex);


		fptr = fopen(world->files[current],"r");
		if (fptr==NULL) {
			fprintf(stderr, "File [%s] does not exist\n", world->files[current]);
			continue;
		}
		serviced+=1;
		
		// Input into buffer
		while (getline(&input, &len, fptr)>0) {
			char *host = strdup(input);
			for (unsigned int i=0; i<strlen(host); i++) {
				if (host[i]=='\n')
					host[i]='\x00';
			}
		

			sem_wait(&world->buffer->pr_ctr);
			sem_wait(&world->buffer->b_mutex);
			
			world->buffer->buff[world->buffer->size]=host;
			world->buffer->size+=1;

			sem_post(&world->buffer->cn_ctr);
			sem_post(&world->buffer->b_mutex);
		}

		fclose(fptr);
	}
	if (input)
		free(input);
	
	
	return arg;	
}

static void* resolver(void *arg) {
	struct resolve_store* world = arg;
	char *host;
	int succ;

	while (1) {
		// Pop hostname off buffer
		sem_wait(&world->buffer->cn_ctr);
		sem_wait(&world->buffer->b_mutex);
		if (world->buffer->size==0) {
			sem_post(&world->buffer->b_mutex);
			sem_post(&world->buffer->cn_ctr);
			break;
		}

		world->buffer->size-=1;
		host = world->buffer->buff[world->buffer->size];
		world->buffer->buff[world->buffer->size] = NULL;
		
		sem_post(&world->buffer->pr_ctr);
		sem_post(&world->buffer->b_mutex);

		// Perform lookup
		char ip[MAX_IP_LENGTH];
		succ = dnslookup(host, ip, MAX_IP_LENGTH);

		FILE *output = fopen(world->output, "a");
		sem_wait(&world->mutex);
		if (succ==0) {
			fprintf(output, "%s,%s\n", host, ip);
		}
		else {
			fprintf(output, "%s,\n", host);
			fprintf(stderr, "%s could not be reached.\n", host);
		}
		sem_post(&world->mutex);


		fclose(output);
		free(host);
	}

	return arg;
}