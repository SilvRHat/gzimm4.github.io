#ifndef MULTI_LOOKUP
#define MULTI_LOOKUP


// Services/ Dependencies
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/time.h>

// Const/ Macros
#define ARRAY_SIZE 20
//#define MAX_INPUT_FILES 10
#define MAX_RESOLVER_THREADS 40
#define MAX_REQUESTER_THREADS 20
//#define MAX_NAME_LENGTH 1025
#define MAX_IP_LENGTH 20

// Data Structs
struct buff_info {
	int size;
	char** buff;
	sem_t pr_ctr, cn_ctr, b_mutex;
};

struct request_store {
	int fi;				// Next file to process
	int fmax;			// Number of files
	char **files;		// Pointer to start of files
	sem_t mutex;	// Request Pool access to change variables
	struct buff_info *buffer;
	char* output;
};

struct req_thr_info {
	struct request_store *shared;
	pthread_t id;
};

struct resolve_store {
	char* output;
	sem_t mutex;
	struct buff_info *buffer;
};


// Functions
void exit_err(char *msg);
static void* requester(void *arg);
static void* resolver(void *arg);
int min(int a,int b );


#endif